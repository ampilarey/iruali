<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        // loyalty_points_earned already exists, nothing to do
    }

    public function down()
    {
        // loyalty_points_earned already exists, nothing to do
    }
}; 