<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        // referral_code and referred_by already exist, nothing to do
    }

    public function down()
    {
        // referral_code and referred_by already exist, nothing to do
    }
}; 